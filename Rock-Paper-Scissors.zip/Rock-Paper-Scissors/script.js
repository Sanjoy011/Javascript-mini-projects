let userScore = 0;
let computerScore = 0;

const userChoise = document.querySelectorAll(".choice");
const msg = document.querySelector("#msg");

const userScoreNumber = document.querySelector("#user-score");
const computerScoreNumber = document.querySelector("#comp-score");

// User Choose elements
userChoise.forEach((choise) => {
    choise.addEventListener("click", () => {
        const userChoiseId = choise.getAttribute("id");
        playGame(userChoiseId);
        console.log(userChoiseId);
    });
});

//Conditions use in choose User
const playGame = (userChoise) => {

    let comChoose = genComChoise()
    
    if(userChoise === comChoose){
        drawGame();
    }else{
        let userWin = true;
        if(userChoise === "rock"){
            userWin = comChoose === "paper" ? false : true;
        }else if(userChoise === "paper"){
            userWin = comChoose === "scissors" ? false : true;
        }else{
            userWin = comChoose === "rock" ? false : true;
        }
        showWinner(userWin,userChoise,comChoose);
    };

};

const showWinner = (userWin,userChoise,comChoose) => {
    if(userWin){
        userScore++;
        userScoreNumber.innerHTML = userScore;
        msg.innerHTML = `You win! Your ${userChoise} beats ${comChoose}`
        msg.style.backgroundColor = "green"
    }else{
        comChoose++;
        comChoose.innerHTML = computerScore;
        msg.innerHTML = `You lost. ${comChoose} beats your ${userChoise}`;
        msg.style.backgroundColor = "red";
    };
};

const drawGame = () => {
    msg.innerHTML = `Game was Draw. Play again.`
};

const genComChoise = () => {
    const options = ["rock","paper","scissors"];
    const randId = Math.floor(Math.random() * 3);
    console.log(`computer select index number ${randId}, and choose items ${options[randId]}`);
    return options[randId];
};